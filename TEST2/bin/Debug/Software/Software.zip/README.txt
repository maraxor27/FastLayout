Put shortcup into [win + R] "shell:startup".
To use "WIN + LeftCTRL" then click on window.
While holding WIN, click leftCTRL to toggle layout.